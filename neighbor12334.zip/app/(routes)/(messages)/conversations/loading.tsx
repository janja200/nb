import LoadingModal from "@/components/messages/modals/LoadingModal";


const Loading = () => {
  return ( 
    <LoadingModal />
  );
}
 
export default Loading;
