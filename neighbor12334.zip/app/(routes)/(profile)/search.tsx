import Header from "@/components/profile/Header";

const Search = () => {
  return ( 
    <>
      <Header label="Search" />
    </>
   );
}
 
export default Search;