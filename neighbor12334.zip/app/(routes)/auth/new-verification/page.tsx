import { NewVerificationForm } from "@/components/auth/new-verification-form";

const NewVerificationPage = () => {
  return ( 
    <NewVerificationForm />
   );
}
 
export default NewVerificationPage;