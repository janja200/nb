import { LoginForm } from "@/components/auth/login-form";

const LoginPage = () => {
  return ( 
    <LoginForm />
  );
}
 
export default LoginPage;